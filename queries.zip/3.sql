select distinct  movies.mov_title
from moviescast as m1 , moviescast as m2 , movies
where m1.act_id = m2.act_id
and m1.mov_id <> m2.mov_id
and movies.mov_id = m1.mov_id
